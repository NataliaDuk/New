<?php


class Ul extends TList
{
public function __construct($data)
{
    parent::__construct($data);
}
}