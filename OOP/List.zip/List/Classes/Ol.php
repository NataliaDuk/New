<?php


class Ol extends TList
{
public function __construct($data)
{
    parent::__construct($data);
}
}