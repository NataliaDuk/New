<?php
function test($var1, $var2)
{
    if ($var1 === $var2) {
        echo "Тест пройден\n";
    } else {
        echo "Тест НЕ пройден\n";
    }
}