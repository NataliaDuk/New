<?php

use Classes\Router;

include "../vendor/autoload.php";

 (new Router())->run();
