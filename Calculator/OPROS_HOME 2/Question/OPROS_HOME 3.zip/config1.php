<?php

$fileName = "vote.txt";
$separate = " - ";

?>