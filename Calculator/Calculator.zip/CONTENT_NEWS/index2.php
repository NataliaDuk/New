<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONTENT</title>
</head>
<body>
    <h2>Введите ссылку на страницу с новостью на сайте
    <a href="https://www.onliner.by/">Onliner.by</a>
</h2>
<form action="content.php" method="post">
    <input type="text" name="url">
    <input type="submit" value="ок">
</form>    
</body>
</html>